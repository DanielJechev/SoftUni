package com.company;

public class Animal {
    public  void eat(){
        System.out.println("eating...");
    }
}
