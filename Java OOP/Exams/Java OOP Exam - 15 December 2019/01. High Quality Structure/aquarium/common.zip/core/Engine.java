package aquarium.core;

public interface Engine extends Runnable {
}

